eng = int(input('eng score'))
math = int(input('math score'))
if eng >= 90 and math >= 90:
    print ('award')
elif eng >= 90 or math >= 90:
    print ('u need to be better')
else:
    print ('ur dead') 